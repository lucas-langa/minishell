#include "minishell.h"

void 	decypher(char **av, char ***envcpy)
{
	pid_t x;
	int status;

	if (!av)
		return ;
	else if (!ft_strcmp("ls", av[0]))
 	{
		x = fork();
		if (x > 0)
			waitpid(x, &status,0 | WUNTRACED);
		else if (!x)
			execve("/bin/ls", av, *envcpy);
		else
			ft_putstr("fork failed, could'nt create a new process -_-");
	}
	else if (!ft_strcmp("exit", av[0]))
		exit(0);
	else if (!ft_strcmp(av[0], "unsetenv"))
		rm_2d_arr_str(envcpy, av[1]);
	else if (!ft_strcmp(av[0], "setenv"))
		add_2d_arr_str(envcpy, av);
	else if (!ft_strcmp(av[0], "env"))
		ft_strarrayiter(*envcpy, &disp);
	else if (!ft_strcmp(av[0], "\n"))
		return ;
	else
		puts("no such command");
	return ;
}


char  	**get_args(void)
{
	t_list *node;
	char *line;
	char **args;

	args = NULL;
	node = NULL;
	line = NULL;
	if (get_next_line(0, &line) == 1)
		node = ft_lstnew(line);
	if (!node->content)
	{
		free(node);
		return (NULL);
	}
	else
		args = ft_strsplit(node->content, ' ');
	return (args);

}

int 	main(int ac, char **av, char **env)
{
	char *line;
	char **args;
	char **envcp;
	
	envcp = NULL;
	line = NULL;
	args = NULL;
	envcp = cpy_2darr(env);
 	while (42)
	{
		ft_putstr("$> ");
		args = get_args();
		decypher(args, &envcp);
		if (args == NULL)
			mk_2D_arr_clean(&args);
	}
	return (0);
}
