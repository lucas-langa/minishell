#include "minishell.h"

int 	find_item(char **arr2d, char **item)
{
	int i;
	char *temp;
	int index;


	temp = NULL;
	i = 0;
	if ((index = ft_indexof(item[1], '=')) != -1)
		temp = ft_strsub(item[1], 0, index);
	else
		temp = ft_strdup(item[1]);
	while (arr2d[i])
	{
		if (ft_strncmp(arr2d[i], temp, ft_strlen(temp)) == 0)
			return (i);
		i++;
		
	}
	return (-1);
}

void	add_2d_arr_str(char ***env, char **item)
{
	char **new;
	int new_len;
	int j = 0;
	int i = 0;
	char *temp;

	temp = NULL;
	new = NULL;
	if ((i = find_item(*env, item)) != -1)
	{
		ft_strdel(&(*env)[i]);
		if ((j = ft_indexof(item[1], '=')) != -1)
			(*env)[i] = ft_strdup(item[1]);
		else
		{
			temp = ft_strjoin(item[1], "=");
			(*env)[i] = ft_strjoin(temp, item[2]);
			ft_strdel(&temp);
		}
		return ;
	}
	else
	{
		j = get_2darr_len(*env);
		new = gimme_2darr_space(j + 2);
		i = 0;
		while ((*env)[i])
		{
			new[i] = ft_strdup((*env)[i]);
			i++;
		}		
		if ((j = ft_indexof(item[1], '=')) != -1)
			new[i++] = ft_strdup(item[1]);
		else
		{
			temp = ft_strjoin(item[1], "=");
			new[i++] = ft_strjoin(temp, item[2]);
			ft_strdel(&temp);		 
		} 
		new[i] = NULL;
		mk_2D_arr_clean(env);
		*env = new;

	}
	return ;
}

void 	rm_2d_arr_str(char ***old, char *item)
{
	char **new;
	int new_len = 0;
	int j =0 ;
	int i = 0;

	new = NULL;
	if ((new_len = get_2darr_len(*old)) > 0)
		if (!(new = (char**)malloc((new_len - 1) * sizeof(char*))))
			return ;
	while ((*old)[i])
	{
		if (!ft_strncmp((*old)[i], item, ft_strlen(item)))
			i++;
		else
			new[j++] = ft_strdup((*old)[i++]);
	}
	new[j] = NULL;
	mk_2D_arr_clean(old);
	*old = new;
}