#include <sys/wait.h>

int	main(void)
{
	char buf[1024];
	pid_t pid;
	int status;

	printf("%% ");
	while (fgets(buf, 1024m stdin))
	{
		if (buf[strlen(buf) - 1 ] )
	}
	return 0;
}