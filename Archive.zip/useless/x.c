#include <stdio.h>
int main(void)
{
	float xx = 9.9999999;
	printf("%f\n",xx);
}
