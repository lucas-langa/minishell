#include "minishell.h"

void 	ex(void)
{
	father = fork();
		if (father > 0)
		{
			wait(&status);
			puts("I'm your father");
		}
		if (!father)
		{
			execve("/bin/ls", av, NULL);
		}
		return ;
}

int 	main(int ac, char **av)
{
	pid_t 	father;
	int status;

	int i = ac;
	i--;
	puts("% ");
	while (1)
	{
		ex();		
	}
}

