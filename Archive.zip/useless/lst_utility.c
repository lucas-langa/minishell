#include "minishell.h"

int     node_cnt(t_list *node)
{
    int i;
    t_list *ptr;

    ptr = NULL;
    ptr = node;
    while (ptr)
    {
        i++;
        ptr = ptr->next;
    }
    return (i);
}