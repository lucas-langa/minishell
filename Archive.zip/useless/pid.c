#include <unistd.h>
#include <stdio.h>
int 	main(void)
{
	printf("%ld", getpid());
}