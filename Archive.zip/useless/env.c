#include <stdio.h>
#include "minishell.h"

char  **jak_env_var(t_list *envlist, char *var, char delim)
{
	t_list *nav;
	char **varstr;

	nav = envlist;
	varstr = NULL;
	while (nav)
	{
		if (!ft_strncmp(nav->content, var, ft_strlen(var)))
			break ;
		nav = nav->next;
	}
	varstr = ft_strsplit(nav->content += ft_indexof(nav->content, '/'), delim);
	// nav->content += ft_indexof(nav->content,'/')
	return (varstr);
}
#include <signal.h>
char	*check(char **paths,char *av)
{
	char *path;
	int i;
	char *temp;

	i = 0;
	path = ft_strjoin("/", av);
	while (paths[i])
	{
		temp = ft_strjoin(paths[i],path);
		if (access(temp, F_OK) == 0)
		{
			return (temp);
		}
		ft_strdel(&temp);
		i++;
	}
	return (NULL);
}

void	ft_unsetenv(t_list *envcpy, char *var)
{
	t_list *nav;
	t_list *temp;

	temp = NULL;
	nav = envcpy;
	while (nav && (ft_strncmp(nav->content, var, ft_strlen(var))))
		nav = nav->next;
		
		temp = nav;
		nav = temp->next;
		free(temp);
		temp = NULL;
 	/* else
	{
		free(nav);
		nav = NULL;
	} */
}

int main(int ac, char **av, char **env)
{
	t_list *envcpy;
	t_list *head = NULL;

	pid_t i;
	int status;
	envcpy = mk_envcpy(env);
	t_list *ptr;
	
	char **paths;
	paths = jak_env_var(envcpy, "PATH", ':');
	ft_unsetenv(envcpy, "OLDPWD");
	ft_lstiter(envcpy, &disp);
	// ft_strarrayiter(paths, &disp);
	char *path = check(paths,av[1]);
	int status = 0;
	sh_init();
	// puts(path);
	 /* i = fork();
	++av;
	if (i == 0)
	{
		// puts(paths);
		execve(path, av, env);
	}
	else if(i > 0 )
	{
		waitpid(i, &status, 3);
	}
	else
		puts("error");  */
}

void 	sh_init(void)
{
	char *line;
	char **args;

	args = NULL;
	line = NULL;
	/* while (waiting)
	{ */
		if ((get_next_line(0, &line)) != -1)
			args = ft_strsplit(line, ' ');
		// waiting = run_args(args);
	// }
}