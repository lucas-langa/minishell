#include <unistd.h>
#include "minishell.h"

int 	main(int ac, char **av,char **env)
{
	char **copy = env;
	execve("/bin/ls", av,NULL);
}
