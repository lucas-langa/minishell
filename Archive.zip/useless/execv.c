#include <unistd.h>

int		main(int argc, char *argv[])
{
	while (42)
		execve("/bin/ls", argv, NULL);
	return 0;
}