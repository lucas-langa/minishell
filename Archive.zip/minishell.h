/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llanga <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/21 14:55:28 by llanga            #+#    #+#             */
/*   Updated: 2018/09/28 10:34:00 by llanga           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H
# include <sys/wait.h>
# include <unistd.h>
# include <stdio.h>
# include "libft/libft.h"

void    disp(char *str);
t_list  *mk_envcpy(char **env);
void    ft_strarrayiter(char **arr, void(*dsp)(char *str));
void    fx_lstiter(t_list *node, void(*dsp)(char *str));
int 	get_2darr_len(char **arr2d);
char 	**cpy_2darr(char **src);
void	del_2d_peasants_data_structure(char **strings);
char 	**gimme_2darr_space(int size);

void	add_2d_arr_str(char ***env, char **item);
void	rm_2d_arr_str(char ***old, char *item);
void    mk_2D_arr_clean(char ***arr);
void 	decypher(char **av, char ***envcpy);
char  	**get_args(void);
int 	just_find_item(char **arr2d, char *item);
int 	find_item(char **arr2d, char **item);
int		ft_indexof(char *str, char c);

int     node_cnt(t_list *node);
#endif
